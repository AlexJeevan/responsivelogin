import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listpage',
  templateUrl: './listpage.component.html',
  styleUrls: ['./listpage.component.css']
})
export class ListpageComponent implements OnInit {

  display="none";
  constructor() { }
  openModal(){
    this.display='block';
  }
  onCloseHandled(){
  this.display='none';
}
  ngOnInit() {
  }

}
