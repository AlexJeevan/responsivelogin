import { Component, OnInit, APP_BOOTSTRAP_LISTENER } from '@angular/core';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
delete()
{
  
}
}
